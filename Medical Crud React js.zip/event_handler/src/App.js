import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Routes, Route } from 'react-router-dom';
import Signup from './component/Signup';
import Login from './component/Login';
import ForgotPassword from './component/ForgotPassword';
import Index from './component/Index';
import Error from './component/Error';


function App() {
  return (
    <>
      <Routes>
        <Route path='/' element={<Signup />}></Route>
        <Route path='/Login' element={<Login />}></Route>
        <Route path='/ForgotPassword' element={<ForgotPassword />}></Route>
        <Route path='/Index' element={<Index />}></Route>
        <Route path='/*' element={<Error />}></Route>
      </Routes>

    </>
  );
}

export default App;
