import React, { useEffect } from 'react'
import { useNavigate } from "react-router-dom";


const Index = () => {

  const navigate = useNavigate();
  const LogOut = () => {
    navigate("/Login");
  };

  const Data = [
    {
      id: 1,
      name: "Abilify",
      quantity: 10,
      price: 250,
    },
    {
      id: 2,
      name: "Bactrim DS",
      quantity: 20,
      price: 190,
    },
    {
      id: 3,
      name: "Canasa",
      quantity: 15,
      price: 150,
    },
    {
      id: 4,
      name: "Dimenhydrinate",
      quantity: 20,
      price: 300,
    },
    {
      id: 5,
      name: "someprazole",
      quantity: 15,
      price: 100,
    },
    {
      id: 6,
      name: "Kineret",
      quantity: 1,
      price: 160,
    },
    {
      id: 7,
      name: "Iclusig",
      quantity: 10,
      price: 150,
    },
    {
      id: 8,
      name: "Kariva",
      quantity: 15,
      price: 350,
    },
    {
      id: 9,
      name: "Metronidazole",
      quantity: 20,
      price: 550,
    },
    {
      id: 10,
      name: "Welchol",
      quantity: 5,
      price: 100,
    },
  ];

  return (


    <>

      <div className='d-flex medications align-items-center'>
        <h6 className='fs-1 mt-4'>Medicine List</h6>

        <div className="text-end">
          <button type="button" className="btn btn-success px-3 btn-sm" onClick={LogOut} >LogOut</button>
        </div>
      </div>

      <hr />

      <div className="container py-3">
        <div className=" mb-3 w-100">
          <div className="pt-4 pb-2">
            <table className="table text-center">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Product</th>
                  <th>Qty</th>
                  <th>Price</th>
                  <th>Edit</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tbody>
                {Data.map(
                  (val, index) => (
                    <tr key={index}>
                      <td>{val.id}</td>
                      <td>{val.name}</td>
                      <td>{val.quantity}</td>
                      <td>{val.price}</td>
                      <td>
                        <button className="btn btn-primary px-3 btn-sm " type="button">Edit</button>
                      </td>
                      <td>
                        <button className="btn btn-danger btn-sm " type="button">Delete</button>
                      </td>
                    </tr>
                  )
                )}
              </tbody>
            </table>
          </div>

        </div>
      </div>

    </>

  );
};

export default Index 