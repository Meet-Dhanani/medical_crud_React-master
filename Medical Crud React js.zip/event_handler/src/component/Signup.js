import React from 'react'
import react, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Signup = () => {

    const navigate = useNavigate();
    const login = () => {
        navigate("/Login");
    };
    const ForgotPassword = () => {
        navigate("/ForgotPassword");
    };

    const url = "http://localhost:3000/Detaills";
    const [data, setdata] = useState({
        name: "",
        email: "",
        password: "",
        cpassword: ""
    });
    const changedata = (e) => {
        setdata({ ...data, [e.target.name]: e.target.value });
        console.log(data);
    };
    const submitdata = (e) => {
        e.preventDefault();

        if (data.email == "" && data.name == "" && data.password == "" && data.cpassword == "") {
            alert("Register field ");
        } else {
            alert("succesfull");
            axios.post(url, data).then((res) => {
                console.log(res.data);
            });
            setdata({
                name: "",
                email: "",
                password: "",
                cpassword: ""
            });
            navigate("/Login")
        }

        document.getElementsByName("name")[0].value = "";
        document.getElementsByName("email")[0].value = "";
        document.getElementsByName("password")[0].value = "";
        document.getElementsByName("cpassword")[0].value = "";
    };


    return (
        <div className='body'>

            <div className="container-fluid position-relative d-flex p-0">
                <div className="container-fluid">
                    <div className="row h-100 align-items-center justify-content-center" style={{ minHeight: '100vh' }}>
                        <div className="col-12 col-sm-8 col-md-6 col-lg-5 col-xl-4">
                            <div className="bg-secondary rounded p-4 p-sm-5 my-4 mx-3">
                                <form onSubmit={submitdata}>
                                    <div className="d-flex align-items-center justify-content-between mb-3">
                                        <a href="index.html">
                                            <h3 className="text-light"><i className="fa fa-user-edit me-2" />DarkPan</h3>
                                        </a>
                                        <h3 className='text-light'>Sign Up</h3>
                                    </div>
                                    <div className="form-floating mb-3">
                                        <input type="text" onChange={changedata} name='name' className="form-control" id="name" placeholder="jhondoe" required />
                                        <label htmlFor="floatingText">Username</label>
                                    </div>
                                    <div className="form-floating mb-3">
                                        <input type="email" onChange={changedata} name='email' className="form-control" id="email" placeholder="name@example.com" required />
                                        <label htmlFor="floatingInput">Email address</label>
                                    </div>
                                    <div className="form-floating mb-3">
                                        <input type="password" onChange={changedata} name='password' className="form-control" id="password" placeholder="Password" required />
                                        <label htmlFor="floatingPassword">Password</label>
                                    </div>
                                    <div className="form-floating mb-4">
                                        <input type="password" onChange={changedata} name='cpassword' className="form-control" id="cpassword" placeholder="Confirm Password" required />
                                        <label htmlFor="floatingPassword"> Confirm Password</label>
                                    </div>
                                    <div className="d-flex align-items-center justify-content-between mb-4">
                                        <div className="form-check">
                                            <input type="checkbox" className="form-check-input" id="exampleCheck1" />
                                            <label className="form-check-label" htmlFor="exampleCheck1">Check me out</label>
                                        </div>
                                        <button className='btn link-light' onClick={ForgotPassword}>Forgot Password</button>
                                    </div>
                                    <button type="submit" className="btn btn-primary py-3 w-100 mb-4">Sign Up</button>
                                    <p className="text-center mb-0">Already have an Account? <button className='btn link-light' onClick={login} >Sign In</button></p>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>


        </div>
    );
};

export default Signup;