import React from 'react'
import Errorpage from '../img/Error.png';

const Error = () => {
  return (
    <div>
      <img src={Errorpage} className='Errorpage' />
    </div>
  )
}

export default Error