import React from 'react'

const ForgotPassword = () => {
    return (
        <div className='body'>

            <div className="container-fluid position-relative d-flex p-0">
                {/* Spinner Start 
                <div id="spinner" className="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
                    <div className="spinner-border text-primary" style={{ width: '3rem', height: '3rem' }} role="status">
                        <span className="sr-only">Loading...</span>
                    </div>
                </div>
             Spinner End */}
                {/* Sign In Start */}
                <div className="container-fluid">
                    <div className="row h-100 align-items-center justify-content-center" style={{ minHeight: '100vh' }}>
                        <div className="col-12 col-sm-8 col-md-6 col-lg-5 col-xl-4">
                            <div className="bg-secondary rounded p-4 p-sm-5 my-4">
                                <div className="text-center mb-3">
                                    <a className="mb-3">
                                        <h3 className="text-light"><i className="fa fa-user-edit me-2" />DarkPan</h3>
                                    </a>
                                    <div className="text-center mb-3">
                                        <span>Enter your e-mail address below and we will send you instructions how
                                            to recover a password.</span>
                                    </div>
                                </div>
                                <div className="form-floating mb-3">
                                    <input type="email" id="email" className="form-control" placeholder="name@example.com" />
                                    <label htmlFor="floatingInput">Email address</label>
                                </div>
                            </div>
                            <button type="button" onclick="recover()" className="btn btn-primary py-3 w-100 mb-4">Recover</button>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    )
}
export default ForgotPassword